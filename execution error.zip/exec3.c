#include <stdio.h>

int main() {
    int x;
    int y = x + 5;  
    printf("%d\n", y);
    return 0;
}
