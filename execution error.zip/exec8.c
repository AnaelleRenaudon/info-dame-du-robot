#include <stdio.h>

int main() {
    int t[3] = {10, 20, 30};
    int i = -1;
    printf("%d\n", t[i]); 
    return 0;
}
